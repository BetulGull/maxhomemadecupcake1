package com.example.demo.Services;

public class CupcakeNotFoundException extends Exception {
    public CupcakeNotFoundException(String message) {
        super(message);
    }
}
