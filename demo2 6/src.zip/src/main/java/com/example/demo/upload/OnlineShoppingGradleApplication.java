package com.example.demo.upload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShoppingGradleApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnlineShoppingGradleApplication.class, args);
    }

}
